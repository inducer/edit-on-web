from eow import main
main()
